<?php
/**
 * Box Sizes for dhl in array format
 */
return array(
	
);
