<tr valign="top" id="ec_service_options">
	<td class="titledesc" colspan="2" style="padding-left:0px">
	<strong><?php _e( 'Services', 'wf_dhl_wooCommerce_shipping' ); ?></strong><br><br>
		<table class="dhl_ec_services widefat">
			<thead>
				<th class="sort">&nbsp;</th>
				<th><?php _e( 'Service Code', 'wf_dhl_wooCommerce_shipping' ); ?></th>
				<th><?php _e( 'Name', 'wf_dhl_wooCommerce_shipping' ); ?></th>
				<th><?php _e( 'Enabled', 'wf_dhl_wooCommerce_shipping' ); ?></th>
				<th><?php echo sprintf( __( 'Price Adjustment (%s)', 'wf_dhl_wooCommerce_shipping' ), get_woocommerce_currency_symbol() ); ?></th>
				<th><?php _e( 'Price Adjustment (%)', 'wf_dhl_wooCommerce_shipping' ); ?></th>
			</thead>
			<tbody>
				<?php
					$sort                   = 0;
					$this->ordered_services = array();

				foreach ( $this->services as $code => $name ) {

					if ( isset( $this->custom_services[ $code ]['order'] ) ) {
						$sort = $this->custom_services[ $code ]['order'];
					}

					while ( isset( $this->ordered_services[ $sort ] ) ) {
						$sort++;
					}

					$this->ordered_services[ $sort ] = array( $code, $name );

					$sort++;
				}

					ksort( $this->ordered_services );

				foreach ( $this->ordered_services as $value ) {
					$code = $value[0];
					$name = $value[1];
					?>
						<tr>
							<td class="sort"><input type="hidden" class="order" name="dhl_ec_service[<?php echo $code; ?>][order]" value="<?php echo isset( $this->custom_services[ $code ]['order'] ) ? $this->custom_services[ $code ]['order'] : ''; ?>" /></td>
							<td><strong><?php echo $code; ?></strong></td>
							<td><input type="text" name="dhl_ec_service[<?php echo $code; ?>][name]" placeholder="<?php echo $name; ?>" value="<?php echo isset( $this->custom_services[ $code ]['name'] ) ? $this->custom_services[ $code ]['name'] : ''; ?>" size="50" /></td>
							<td><input type="checkbox" name="dhl_ec_service[<?php echo $code; ?>][enabled]" <?php checked( ( ! isset( $this->custom_services[ $code ]['enabled'] ) || ! empty( $this->custom_services[ $code ]['enabled'] ) ), true ); ?> /></td>
							<td><input type="text" name="dhl_ec_service[<?php echo $code; ?>][adjustment]" placeholder="N/A" value="<?php echo isset( $this->custom_services[ $code ]['adjustment'] ) ? $this->custom_services[ $code ]['adjustment'] : ''; ?>" size="4" /></td>
							<td><input type="text" name="dhl_ec_service[<?php echo $code; ?>][adjustment_percent]" placeholder="N/A" value="<?php echo isset( $this->custom_services[ $code ]['adjustment_percent'] ) ? $this->custom_services[ $code ]['adjustment_percent'] : ''; ?>" size="4" /></td>
						</tr>
						<?php
				}
				?>
			</tbody>
		</table>
	</td>
</tr>
