<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $woocommerce;

/**
 * Array of settings
 */
return array(
	'wf_dhl_tab_box_key' => array(
		'type'          => 'wf_dhl_tab_box'
		),
 
);
