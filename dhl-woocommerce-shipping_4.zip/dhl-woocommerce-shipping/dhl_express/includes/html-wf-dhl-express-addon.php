<tr valign="top" id="service_options" class="license_tab_field">
	<?php $url = untrailingslashit(plugins_url()) . '/dhl-woocommerce-shipping/dhl_express/resources/images/'; ?>
	<td>
		<strong><div style="background-color:#133558;height: 30px;color:white;"><center><?php _e( 'DHL Express Related Addons', 'wf-shipping-dhl' ); ?></center></div></strong>
		<br>
		<table class="dhl_services widefat">

			<th>
				<div>
						<div>
							<center><img src="<?php echo $url . 'ELEX-DHL-Express-Bulk-Label-Printing-Add-On-Logo.png'; ?>" class="marketing_logos" style="border-radius: 8px;height:200px;"></center>
						</div>
						<div>
							<h5><a href="https://elextensions.com/plugin/elex-woocommerce-dhl-express-bulk-label-printing-add-on/" data-wpel-link="internal" target="_blank"><center>ELEX WooCommerce DHL Express Bulk Label Printing Add-On</center></a> </h5>
						</div>
				</div>
			</th>

			<th>
				<div>
						<div>
							<center><img src="<?php echo $url . 'DHL-Auto-Generate-Email-Labels-Add-On-600x600.png'; ?>" class="marketing_logos" style="border-radius: 8px;height:200px;"></center>
						</div>
						<div>
							<h5><a href="https://elextensions.com/plugin/elex-woocommerce-dhl-express-auto-generate-email-labels-add-on/" data-wpel-link="internal" target="_blank"><center>ELEX WooCommerce DHL Express Auto-Generate & Email Labels Add-On</center></a> </h5>
						</div>
				</div>
			</th>
		</table>
	</td>
</tr>
<tr valign="top" id="service_options" class="license_tab_field">
	<td>
		<strong><div style="background-color:#133558;height: 30px;color:white;"><center><?php _e( 'ELEX Plugins You May Be Interested In', 'wf-shipping-dhl' ); ?></center></div></strong>
		<br>
		<table class="dhl_services widefat">
			<th>
				<div>
						<div>
							<center><img src="<?php echo $url . 'ELEX-Conditionally-Hide-WooCommerce-Shipping-Method-Logo.png'; ?>" class="marketing_logos" style="border-radius: 8px;height:200px;"></center>
						</div>
						<div>
							<h5><a href="https://elextensions.com/plugin/conditionally-hide-woocommerce-shipping-methods-plugin/" data-wpel-link="internal" target="_blank"><center>ELEX Hide WooCommerce Shipping Methods Plugin</center></a> </h5>
						</div>
				</div>
			</th>

			<th>
				<div>
						<div>
							<center><img src="<?php echo $url . 'ELEX-Bulk-Edit-Products-Prices-Attributes-for-WooCommerce-Logo.png'; ?>" class="marketing_logos" style="border-radius: 8px;height:200px;"></center>
						</div>
						<div>
							<h5><a href="https://elextensions.com/plugin/bulk-edit-products-prices-attributes-for-woocommerce/" data-wpel-link="internal" target="_blank"><center>ELEX WooCommerce Bulk Edit Products, Prices & Attributes</center></a> </h5>
						</div>
				</div>
			</th>
			<th>
				<div>
						<div>
							<center><img src="<?php echo $url . 'ELEX-WooCommerce-Catalog-Mode-Role-Based-Pricing-Plugin-Logo.png'; ?>" class="marketing_logos" style="border-radius: 8px;height:200px;"></center>
						</div>
						<div>
							<h5><a href="https://elextensions.com/plugin/woocommerce-catalog-mode-wholesale-role-based-pricing/" data-wpel-link="internal" target="_blank"><center>ELEX WooCommerce Catalog Mode, Wholesale & Role Based Pricing</center></a> </h5>
						</div>
				</div>
			</th>
		</table>
	</td>
	
</tr>
