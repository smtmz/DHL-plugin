<?php
/**
 * dhl Service codes in array format
 */
return array(
	'DeliveryOnTime'                 => 'Delivery On Time',
	'DeliveryEarly'                  => 'Delivery Early',
	'Express0900'                    => 'Express 09:00',
	'Express1000'                    => 'Express 10:00',
	'Express1200'                    => 'Express 12:00',
	'DeliveryAfternoon'              => 'Delivery Afternoon',
	'DeliveryEvening'                => 'Delivery Evening',
	'ExpressSaturday'                => 'Express Saturday',
	'ExpressSunday'                  => 'Express Sunday',
);
