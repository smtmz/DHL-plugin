<?php
return array(
	'SMALL' => array(
		'name'=>'SMALL',
		'length'=>'80',
		'width' =>'50',
		'height'=>'35',
		'min_weight'=>'0',
		'max_weight'=>'20'
	),


	'MEDIUM' => array(
		'name'=>'MEDIUM',
		'length'=>'80',
		'width' =>'50',
		'height'=>'35',
		'min_weight'=>'20',
		'max_weight'=>'31'
	),


	'PALLET' => array(
		'name'=>'PALLET',
		'length'=>'80',
		'width' =>'50',
		'height'=>'35',
		'min_weight'=>'50',
		'max_weight'=>'1000'
	),
);

