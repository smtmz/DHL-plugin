=== ELEX DHL Express/DHL Paket WooCommerce Shipping Plugin with Print Label ===
Contributors: elex
Version: 7.0.2

Tags: DHL, DHL Paket, Shipping rates, Label printing, Auto Tracking, Shipping, WooCommerce, Wordpress
Requires at least: 3.0.1
Tested up to: 6.5

== Description ==
== Screenshots ==
== Changelog ==

Please refer our product page for above details --> https://elextensions.com/plugin/woocommerce-dhl-express-ecommerce-paket-shipping-plugin-with-print-label/

= Contact Us =
Please use our contact us form --> https://elextensions.com/support/
Or make use of FREQUENTLY ASKED QUESTIONS section in individual product page --> https://elextensions.com/plugin/woocommerce-dhl-express-ecommerce-paket-shipping-plugin-with-print-label/

== Installation ==
https://elextensions.com/documentation/#elex-dhl-shipping

== Tutorial / Manual ==
https://elextensions.com/documentation/#elex-dhl-shipping
